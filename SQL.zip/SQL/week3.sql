use hr;
show tables;

select * from employees limit 2;

-- Show the first name, last name, dept id, dept name, city, state province of those employees who contain 
-- the letter 'z' in their first name

select e.first_name, e.last_name, e.department_id, d.department_name, l.city, l.state_province 
from employees e
inner join departments d on e.department_id = d.department_id
inner join locations l on d.location_id = l.location_id
where first_name like '%z%';


-- write a query to display job_title, dept id, full name , start date, end date for all the jobs which 
-- started on or after 1st Jan 1993, and ended on or before 31 aug 2000.

 select j.job_id, jj.job_title, department_id, concat(first_name, ' ', last_name) full_name, start_date, end_date 
 from employees e
 inner join job_history j on e.employee_id = j.employee_id
 inner join jobs jj on j.job_id = jj.job_id
 where j.start_date >= '1993-01-01' and end_date <= '2000-08-31';
 
 -- Display employee number , full name, job_title for all emp whose salary is smaller than min salary 
 -- of those emp whose job_title is Programmer.
 
 select employee_id, concat(first_name, ' ', last_name) full_name, job_title, salary
 from employees e inner join jobs j on e.job_id = j.job_id where salary < (
 select min(salary) from employees e1 inner join jobs j1 on e1.job_id = j1.job_id 
 where job_title = 'Programmer'); 
 
 select min(salary) from employees e1 inner join jobs j1 on e1.job_id = j1.job_id 
 where job_title = 'Programmer';
 
 -- WAQ to display country name, city, count of departments where at least 2 employees are working.
select country_name, city, count(department_id) from countries c 
join locations l on c.country_id = l.country_id
join departments d on l.location_id = d.location_id
where department_id in (
select department_id from employees group by department_id having count(employee_id) >=2 )
group by country_name, city;

-- WAQ to display first name, last name, salary and dept id for employees who earn less than the avg salary
-- , and who work at a dept where Laura is working as a first name holder.

select * from employees
where salary < ( select avg(salary) from employees) and department_id in ( select department_id from employees where
first_name like "%Laura%");

-- WAQ to find max salary of the most recent job that every employee holds.
select employee_id, hire_date, j.job_id, max_salary from employees e
left join jobs j on e.job_id = j.job_id;

-- WAQ to fetch the emp id, first name, last name, salary and dept id of those emplyees who have salary 
-- more than avg salary of their respective depts.

-- WAQ to find the old designation and new designation of all emp where old designation is not null.