use hr;
select * from employees where first_name  LIKE '%h' and length(first_name) = 6;

select manager_id, first_name, last_name, salary from employees where manager_id in
(select manager_id from employees 
where manager_id is not null group by manager_id having salary = min(salary)) order by salary DESC;

select manager_id, first_name, last_name, salary, commission_pct, hire_date from employees where hire_date in 
(select hire_date from employees
where commission_pct is not null group by hire_date having hire_date = min(hire_date)) order by hire_date DESC;

select employee_id, hire_date, CASE WHEN hire_date <= '1999-12-31' then  "Eligible" else "Not Eligible" END 
AS eligibility From employees;

select employee_id, hire_date, IF  (hire_date <= '1999-12-31', "Eligible", "Not Eligible") AS eligibility From employees;

select employee_id, salary, CASE
WHEN salary < 5000 THEN 'Tax Slab A'
WHEN salary >= 5000 and salary < 10000 THEN 'Tax Slab B'
WHEN salary >= 10000 and salary < 15000 THEN 'Tax Slab C'
ELSE 'Tax Slab D'
END As Tax_Slab from employees;

select year(hire_date) , count(employee_id) from employees group by year(hire_date) order by year(hire_date) DESC;

-- Create a department col which replaces missing department_ids with "To be assigned" 
-- but only for employee ids > 170.

select employee_id, ifnull(department_id, 'To be assigned') as department from employees where employee_id>170;

-- Create a manager col containing "YES" for those emp who are "MGR" or "MAN" , else "NO"
select employee_id, job_id,
case when job_id like '%MGR%' or job_id like '%MAN%' then 'YES'
else 'NO' end as is_manager from employees;

-- Increase salary of employees by 5%. However, if job_id is 'SA_REP", then increase salary by 25% 
-- and if job_id is IT_PROG, then increase salary by 20%. 
-- Show emp id, first_name, last_name, salry and new_Salary.

select employee_id, first_name, last_name, job_id, salary, CASE
WHEN job_id = 'SA_REP' THEN salary * 1.25
WHEN job_id = 'IT_PROG' THEN salary * 1.20
ELSE salary * 1.05
END As new_salary from employees;

select employee_id, department_id , salary from employees order by department_id, salary DESC;

select employee_id, first_name, last_name, department_id , salary, job_id from employees 
order by 4, 5 DESC;

-- Display min, max and avg (in 2 decimal places) salary of employees  for dept id 60 and 80.
select department_id, min(salary), max(salary), ROUND(avg(salary),2) from employees 
where department_id in (60,80)
group by department_id;

-- Display dept id, job id, count of emp, avg slary of emp in each dept  
-- for the diferent job_ids and order wrt to dpet id and job id.

select department_id, job_id, count(*), AVG(salary) from employees
group by department_id, job_id
order by department_id, job_id;

-- Display dept id, count of emp, avg salary of employees who are clerks.

select department_id, count(employee_id), avg(salary) 
from employees where job_id like '%CLERK%' group by department_id;

-- Display the employees whose salary is greater than the avg slary of their departments.

select * from employees e1 
where e1.salary > (select avg(e2.salary) from employees e2 where e2.department_id=e1.department_id);

select avg(salary) from employees where department_id = 60; 